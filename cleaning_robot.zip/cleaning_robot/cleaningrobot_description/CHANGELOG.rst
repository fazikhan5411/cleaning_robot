^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package cleaningrobot_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.1 (2019-04-13)
------------------
* cleanup package.xml/CMakeLists.txt, update run_depends with roslaunch_add_file_check
* Fix camera position
* Add raspi camera module link
* Append package dependencies
* Add setting for CMakeLists.txt to install required directories
* Organize the files of robot_description
* Change to run amcl
* Fix RPLIDAR orientation
* Initial commit
* Contributors: Faizan Ali
