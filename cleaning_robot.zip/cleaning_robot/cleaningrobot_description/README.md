# cleaningrobot_description

This package contains the robot model files(URDF, meshes).

# Visualize the robot model in rviz

```
$ roslaunch cleaningrobot_description main.launch
```
