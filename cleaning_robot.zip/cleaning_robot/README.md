# cleaningrobot

we are making final year project at UET,Taxila Chakwal Campus. Our aim is to make an efficient algorithum for cleaning robot. there is complete guide to use this package.

STEPS TO COMPLETE THE PROJECT
1) CREATING PACKAGE 
2) URDF MODELING 
3) 3D-WORLD GAZEBO
4) SLAM IMPLEMENTATION - GMAPPING
5) AUTONOMOUS MAPPING
6) TAGGING THE MAP
7) MAKING EFFICIENT ALGORITHM

### ROS

Install ROS Melodic following the install guide:

- [Ubuntu install of ROS Melodic]


### Raspberry Pi

You can use Raspberry Pi 2 Model B or Raspberry Pi 3. Pi3 has internal
WiFi module while Pi2 does not. The software installation is slightly
different, see Software section.

### USB serial cable

You need a USB-serial converter to make the Roomba and Raspberry Pi
communicate. We notice this product is very handy to make the
cable. Just cut the cable and solder to mini-DIN 9 pin connector.

### Frame

3D printable data (STL) are available in

- [cleaningrobot](http://www.thingiverse.com/thing:2209131)

### ROS Commands to run the code.
```
roslaunch cleaningrobot_description main.launch
roslaunch gazebo_ros empty_world.launch
roslaunch cleaningrobot_description gmapping.launch
```
After that we can start making map and work on SLAM



