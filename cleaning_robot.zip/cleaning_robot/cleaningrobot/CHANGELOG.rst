^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package cleaningrobot
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.2 (2017-05-09)
------------------
* add metapackage
* Contributors: Faizan Ali

0.0.1 (2017-04-13)
------------------
