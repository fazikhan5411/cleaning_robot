^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package cleaningrobot_bringup
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.1 
------------------
* Add remote operation setting for gmapping launch
* Change operation mode from full to safe
* cleanup package.xml/CMakeLists.txt, update run_depends with roslaunch_add_file_check
* Add launch_rviz to teleop_joy launch
* Add raspi camera module launch
* Modify device install scripts
* Append package dependencies
* Add xbox joypad config and make it default
* Add scripts for udev.rules
* Add joypad teleop launch file and config file
  - We need config file for joypads we usually use
* Add doc/ and README.md
* Insert robot_pose_ekf to publish odom frame
* Fix rviz launch arg
* Fix rviz launch arg


