# fazikhan5411@gmail.com_navigation

This package contain launch and config files to navigation for Roomblock.

# How to try with amcl

Launch acml.launch as:

```
$ roslaunch fazikhan5411@gmail.com_navigation amcl.launch map_file:=your_map_file.yaml
```
