^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package cleaningrobot_navigation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.1 (2019-04-13)
------------------
* cleanup package.xml/CMakeLists.txt, update run_depends with roslaunch_add_file_check
* Modify launch file for semnar description
* Add setting for CMakeLists.txt to install required directories
* Add README.md for navigation
* Tune navigation parameters a little
* Finally local cost map appeared
  - Need to avoid to use pre-hydro parameter setting
  - Need to be careful for parameter namespace
* Revert deleted file
* Somehow local costmap doesn't appear
  - Need to investigate on the local costmap setting

