#!/usr/bin/env python

import rospy
import actionlib
import tf
import roslib
import threading

from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal

# the list of points to patrol
waypoints = [
    ['one', (-0.645, 0.81, -0.776)],
    ['two', (-0.813, -1.376, 0.996)],
    ['three', (-0.504, -1.373, 0.586)],
    ['four', (0.545, 1.232, 0.586)],
    ['fifth', (0.087, -1.373, 0.586)],
    ['sixth', (-0.504, -1.373, 0.586)],
    ['seventh', (-0.504, -1.373, 0.586)],
]

class Patrol:

    def __init__(self):
        # Get a move_base action client
        self.client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
        rospy.loginfo('Connecting to move_base...')
        self.client.wait_for_server()
        rospy.loginfo('Connected to move_base.')

    def set_goal_to_point(self, point):

        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = "map"
        goal.target_pose.header.stamp = rospy.Time.now()
        goal.target_pose.pose.position.x = point[0]
        goal.target_pose.pose.position.y = point[1]
        quaternion = tf.transformations.quaternion_from_euler(0.0, 0.0, point[2])
        goal.target_pose.pose.orientation.x = quaternion[0]
        goal.target_pose.pose.orientation.y = quaternion[1]
        goal.target_pose.pose.orientation.z = quaternion[2]
        goal.target_pose.pose.orientation.w = quaternion[3]

        self.client.send_goal(goal)
        wait = self.client.wait_for_result()
        if not wait:
            rospy.logerr("Action server not available!")
            rospy.signal_shutdown("Action server not available!")
        else:
            return self.client.get_result()


if __name__ == '__main__':
    rospy.init_node('patrolling')
    try:
        p = Patrol()
        while not rospy.is_shutdown():
            for i, w in enumerate(waypoints):
                rospy.loginfo("Sending waypoint %d - %s", i, w[0])
                p.set_goal_to_point(w[1])
    except rospy.ROSInterruptException:
        rospy.logerr("Something went wrong when sending the waypoints")
